import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-new-password',
  templateUrl: 'new-password.html'
})
export class NewPasswordPage {

  constructor(public navCtrl: NavController) {
  }
  
}
